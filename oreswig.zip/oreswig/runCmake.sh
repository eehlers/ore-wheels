cmake \
-D Python_ROOT_DIR=$PYTHON_ROOT_DIR \
-D ORE=$ORE -G Ninja ..
