
# Managing Wheels

This document explains how to generate wheels for the ORE project.

[Back to tutorials index](tutorials.00.index.md)

# Prerequisites

## Github Actions

Below is the repo that we use to generate wheels with github actions.  You need
to clone the repo:

https://github.com/eehlers/ore-wheels.git

## Test pypi server

Below is the ORE project on the test pypi server.  You need to acquire access
rights to that project:

https://test.pypi.org/project/open-source-risk-engine/

## Prod pypi server

Below is the ORE project on the prod pypi server.  You need to acquire access
rights to that project:

https://pypi.org/project/open-source-risk-engine/

# Generating Source Tarballs

We need to upload the ORE and ORESWIG source to the GitHub Actions repo which
builds the wheels.  You need to do this twice: 1) zip files for Windows 2) tar
files for posix (macos/linux)

## `zip_files.py`

First, you must ensure:

- That your local copies of the ORE and ORESWIG repos (and their submodules)
  are up to date
- That you have set the correct version number in file:
  `oreswig/OREAnalytics-SWIG/Python/setup.py`

Then cd into the root directory of your ore-wheels repo.  We use the python
script `zip_files.py` to generate the zip files and tarballs.  Before you can
run the script, you need to set some environment variables:

On Windows:

    SET ORE_DIR=C:\repos\ore.github
    SET ORESWIG_DIR=C:\repos\oreswig.github
    SET SWIG_DIR=C:\repos\swigwin\swigwin-4.1.1
    SET PATH=%PATH%;%SWIG_DIR%

On posix:

    export ORE_DIR=/home/erik/repos/ore.github
    export ORESWIG_DIR=/home/erik/repos/oreswig.github

Now you are ready to run the script.

## ORE

To compress the files for ORE and its submodules, do:

    zip_files.py -o

This overwrites the compressed file in the current directory, now you must do a
git commit and push.

## ORESWIG

We do not install swig to the Github Actions Runner.  Instead, we use script `zip_files.py` to perform the following actions:

- compress ORESWIG and its submodules
- uncompress the file, run the swig wrapper, and compress it again

To perform those actions, do:

    zip_files.py -s

This overwrites the compressed file in the current directory, now you must do a
git commit and push.

# Generating the Wheels

Now go on to the ore-wheels repo on github and run the jobs to generate the
wheels.  Download the wheels to your hard drive.

# Uploading the Wheels

## twine

The upload command relies on twine, here are the commands to install twine:

    python -m pip install --upgrade pip
    python -m pip install --upgrade twine

Twine uses the following configuration file to authenticate to the server:

    ~/.pypirc

## Uploading Wheels to the Test Server

The test server for Python wheels is: https://test.pypi.org/

Here is the command to upload the wheels to the test server:

    python -m twine upload --repository test *.whl

Here is the command to install the wheel from the test server (run this within a virtual environment):

    pip install -i https://test.pypi.org/simple/ open-source-risk-engine

## Uploading Wheels to the Production Server

The production server for Python wheels is: https://pypi.org/

Here is the command to upload the wheels to the production server:

    python -m twine upload --repository pypi *.whl

Here is the command to install the wheel from the production server (run this within a virtual environment):

    pip install open-source-risk-engine

