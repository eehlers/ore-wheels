1) Portfolio

   CreditDefaultSwap denominated in USD

2) Market

   Pseudo market data as of 2016-02-05

3) Pricing

   QuantExt’s MidPointCdsEngine used for cds pricing

4) Analytics

   EPE and ENE, at trade and portfolio level

5) Run Example

   python run.py
