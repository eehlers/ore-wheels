1) Portfolio

   Vanilla Swap in EUR
   EUR/USD Cross Currency Swaps, with and without reset
   European Swaption
   FX Forward
   FX Call and Put Options
   Equity Forwards
   European Equity Calls and Puts
   Fixed Rate Bond
   CPI Swap
   YoY Inflation Swap

2) Market

   Pseudo market as of 5/02/2016
   
3) Pricing

   Multi curve, separate discount ad forward curves

4) Analytics

   Sensitivity analysis, Stress analysis, Parametric VaR

5) Run Example

   python run.py

