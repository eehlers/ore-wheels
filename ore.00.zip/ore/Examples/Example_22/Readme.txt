1) Portfolio

   European Option


2) Market

   Pseudo market as of 5/02/2016
   
3) Pricing

   Multi curve, separate discount ad forward curves

4) Analytics

   Sensitivity analysis using equity volatility smile
   (simulating both the full surface and just ATM strikes)

5) Run Example

   python run.py

