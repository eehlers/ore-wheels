1) Portfolio

   Forward Rate Agreement
   Averaging Overnight Swap

2) Market

   Pseudo market data as of 2016-02-05

3) Pricing

   Dual curve, Eonia Discounting, Euribor Forwards 

4) Analytics

   EPE and ENE, compared to European payer and receiver swaption prices 

5) Run Example

   python run.py
