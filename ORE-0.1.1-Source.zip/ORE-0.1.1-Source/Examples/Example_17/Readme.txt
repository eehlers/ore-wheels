1) Portfolio:

   ore.xml: CPI Swap
			YOY Swap
			
   ore_capfloor.xml: YOY Cap
                     YOY Floor
	
   ore_exposure.xml CPI Zero Swap

2) Market

   Pseudo market as of 2016-02-05

3) Pricing

   UKRPI, GBP Libor 6M Discounting

4) Analytics

   EPE and ENE, of CPI Swap

5) Run Example

   python run.py
