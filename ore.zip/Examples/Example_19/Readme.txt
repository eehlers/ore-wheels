Smile Examples

4 swaptions (rates 1%, 2%, 3% and 4%) priced with and without a smile (vol surface vs. vol cube)
