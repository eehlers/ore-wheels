1) Portfolio
   20Y EUR swap, notional = 1M, receive 3% semi-annual and pay EURIBOR
   6M semi-annual. Netting set = CPTY_A.

2) Market
   
   Yield curves 20/05/2016 and normal cap volatility surfaces in EUR,
   GBP and USD
		
3) Pricing

   Multi-curve pricing (EUR collateralised) with normal (Bachelier)
   cap pricing

4) Analytics

   EPE, EE_B, EEPE_BB & EEE_BB compared   

5) Run Example

   python run.py
