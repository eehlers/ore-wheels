#!/bin/bash

cd /Users/roland/Development/ore/Examples/Example_1

python excel_view.py 
