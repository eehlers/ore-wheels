#!/bin/bash

/Applications/LibreOffice.app/Contents/MacOS/python calc_clear.py &
